---
layout: single
title: "À propos"
permalink: /about/
author_profile: true
---

Je m’appelle **Gianni Blaising**.  
L3 Mathématiques (Sorbonne Université). Intérêts : mesure et probabilités, topologie, analyse numérique, geometric deep learning (GDL) et TDA.

Ce site regroupe : une courte biographie, quelques notes, et bientôt une sélection de projets et publications.
