---
layout: single
title: "CV"
permalink: /cv/
author_profile: true
---

Télécharger le CV : [CV (PDF)](/files/CV_Gianni_Blaising.pdf).

> Astuce : uploadez votre fichier dans le dossier `files/` du dépôt, sous le nom `CV_Gianni_Blaising.pdf` pour que le lien ci-dessus fonctionne.
