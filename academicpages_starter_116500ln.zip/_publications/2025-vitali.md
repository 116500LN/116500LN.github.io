---
layout: single
title: "Ensembles de Vitali — intuition, construction et rôle de l’axiome du choix"
collection: publications
permalink: /publications/vitali-sets/
date: 2025-11-12
authors: "G. Blaising"
venue: "Note de blog (mathématiques)"
paperurl: /files/vitali_note.pdf
excerpt: "Un survol des ensembles de Vitali, de la construction par classes de congruence modulo Q et du point où intervient l’axiome du choix."
---

Résumé court. Placez votre PDF dans `files/vitali_note.pdf` ou modifiez `paperurl`.
